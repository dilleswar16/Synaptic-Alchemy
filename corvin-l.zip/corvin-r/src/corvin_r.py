#!/usr/bin/env python3
"""Corvin R — resilience scanner for PR-time config and drift checks.

Deterministic checks across Kubernetes/Helm, Azure PaaS artifacts, and
code-vs-config drift. Textual/heuristic by design: no cluster access, no
third-party dependencies (stdlib only).

Rules:
  CR001  Missing liveness probe        (K8s workload)
  CR002  Missing readiness probe       (K8s workload)
  CR003  Missing resource requests/limits
  CR004  Single replica
  CR005  Unpinned image tag (:latest or none)
  CR006  Workloads without a PodDisruptionBudget (repo-level)
  CR101  Functions host.json without functionTimeout
  CR102  Logic Apps action with retryPolicy "none"
  CR103  APIM forward-request without timeout
  CR104  APIM policy without rate limiting
  CR105  App Service (Bicep) without healthCheckPath
  CR201  Env/config key read in code but defined nowhere
  CR202  Deploy workflow present but no IaC in repo
  CR203  Connection pool total exceeds DB max connections
"""

import argparse
import json
import os
import re
import sys
import urllib.request

RULES = {
    "CR001": ("Missing liveness probe",
              "Workload has no livenessProbe: a hung container is never restarted.", "warning"),
    "CR002": ("Missing readiness probe",
              "Workload has no readinessProbe: traffic reaches pods before they can serve.", "warning"),
    "CR003": ("Missing resource requests/limits",
              "No resources block: the scheduler can't protect this workload or its neighbours.", "warning"),
    "CR004": ("Single replica",
              "replicas: 1 — any pod restart or node drain is an outage.", "warning"),
    "CR005": ("Unpinned image tag",
              "Image uses :latest or no tag: deploys are not reproducible and rollback is a guess.", "warning"),
    "CR006": ("No PodDisruptionBudget",
              "Workloads exist but no PodDisruptionBudget: voluntary disruptions (node "
              "upgrades) can take all replicas down at once.", "note"),
    "CR101": ("No functionTimeout in host.json",
              "functionTimeout is not set: the platform default applies and differs per plan.", "note"),
    "CR102": ("Logic Apps retry disabled",
              "retryPolicy is \"none\": one transient failure of the dependency fails the workflow.", "warning"),
    "CR103": ("APIM forward-request without timeout",
              "No timeout on forward-request: a slow backend holds the gateway connection open.", "warning"),
    "CR104": ("APIM policy without rate limiting",
              "No rate-limit policy found: nothing protects the backend from a client burst.", "note"),
    "CR105": ("App Service without health check",
              "No healthCheckPath: the platform can't detect and recycle unhealthy instances.", "note"),
    "CR201": ("Config key not defined anywhere",
              "The code reads this key but no manifest, values file, app settings, or .env "
              "defines it — likely a crash or misbehaviour on deploy.", "warning"),
    "CR202": ("Deploy workflow but no IaC",
              "This repo deploys to a platform but contains no manifests/IaC: configuration "
              "is click-opsed, unauditable, and unrecoverable.", "warning"),
    "CR203": ("Connection pool exceeds DB capacity",
              "replicas × pool size exceeds the database connection limit.", "warning"),
}

DEFAULT_EXCLUDE_DIRS = {
    "node_modules", "dist", "build", "target", "bin", "obj", ".git", ".venv",
    "venv", "__pycache__", "vendor", "coverage", ".next", "out",
}

ENV_IGNORE_EXACT = {
    "PATH", "HOME", "USER", "HOSTNAME", "PWD", "TEMP", "TMP", "LANG", "TZ",
    "PORT", "NODE_ENV", "PYTHONPATH", "JAVA_HOME", "ASPNETCORE_ENVIRONMENT",
    "DOTNET_ENVIRONMENT", "SPRING_PROFILES_ACTIVE", "ENV", "ENVIRONMENT",
    "DEBUG", "CI", "STAGE",
}
ENV_IGNORE_PREFIX = ("GITHUB_", "WEBSITE_", "FUNCTIONS_", "KUBERNETES_",
                     "AzureWebJobs", "RUNNER_", "npm_", "DOTNET_")

CODE_EXTS = {".py", ".js", ".jsx", ".ts", ".tsx", ".java", ".cs"}

ENV_READ_PATTERNS = [
    re.compile(r"os\.getenv\(\s*['\"]([A-Za-z_][A-Za-z0-9_]*)['\"]"),
    re.compile(r"os\.environ(?:\.get\(\s*|\[\s*)['\"]([A-Za-z_][A-Za-z0-9_]*)['\"]"),
    re.compile(r"process\.env\.([A-Za-z_][A-Za-z0-9_]*)"),
    re.compile(r"process\.env\[\s*['\"]([A-Za-z_][A-Za-z0-9_]*)['\"]"),
    re.compile(r"System\.getenv\(\s*\"([A-Za-z_][A-Za-z0-9_]*)\""),
    re.compile(r"@Value\(\"\$\{([A-Za-z_][A-Za-z0-9_.\-]*?)(?::[^}]*)?\}\"\)"),
    re.compile(r"Environment\.GetEnvironmentVariable\(\s*\"([A-Za-z_][A-Za-z0-9_]*)\""),
]

POOL_PATTERNS = [
    re.compile(r"maximumPoolSize\D{0,10}?(\d+)", re.IGNORECASE),
    re.compile(r"Max\s*Pool\s*Size\s*=\s*(\d+)", re.IGNORECASE),
    re.compile(r"maxPoolSize\D{0,10}?(\d+)", re.IGNORECASE),
    re.compile(r"pool_size\s*[=:]\s*(\d+)"),
]

DEPLOY_MARKERS = re.compile(
    r"azure/webapps-deploy|azure/functions-action|azure/aks-set-context|"
    r"az\s+(functionapp|webapp|containerapp)\s|kubectl\s+apply|helm\s+(upgrade|install)")

WORKLOAD_KINDS = {"Deployment", "StatefulSet", "DaemonSet"}


class Finding:
    def __init__(self, rule, path, line, detail=""):
        self.rule, self.path, self.line, self.detail = rule, path, line, detail

    def message(self):
        base = RULES[self.rule][1]
        return f"{self.detail} — {base}" if self.detail else base


# --- artifact detection ----------------------------------------------------

def classify(path, text):
    base = os.path.basename(path).lower()
    ext = os.path.splitext(base)[1]
    if base == "host.json":
        return "hostjson"
    if base == "local.settings.json":
        return "localsettings"
    if ext in (".yaml", ".yml"):
        if re.search(r"^\s*apiVersion\s*:", text, re.M) and re.search(r"^\s*kind\s*:", text, re.M):
            return "k8s"
        if base.startswith("values"):
            return "helmvalues"
        if base.startswith("docker-compose") or base == "compose.yaml":
            return "compose"
        if "/.github/workflows/" in path.replace("\\", "/"):
            return "workflow"
        return None
    if ext == ".json":
        low = text.lower()
        if "workflowdefinition" in low or ('"triggers"' in low and '"actions"' in low):
            return "logicapp"
        return None
    if ext == ".xml" and "<policies" in text:
        return "apim"
    if ext == ".bicep":
        return "bicep"
    if ext == ".tf":
        return "terraform"
    if base == "dockerfile":
        return "dockerfile"
    if base.startswith(".env"):
        return "envfile"
    if ext in CODE_EXTS:
        return "code"
    return None


def line_of(text, pattern, flags=0):
    m = re.search(pattern, text, flags)
    return text[:m.start()].count("\n") + 1 if m else 1


# --- kubernetes ------------------------------------------------------------

def split_yaml_docs(text):
    """Yield (start_line, doc_text) for each YAML document."""
    docs, cur, start = [], [], 1
    for i, ln in enumerate(text.splitlines(), 1):
        if ln.strip().startswith("---"):
            if any(l.strip() for l in cur):
                docs.append((start, "\n".join(cur)))
            cur, start = [], i + 1
        else:
            cur.append(ln)
    if any(l.strip() for l in cur):
        docs.append((start, "\n".join(cur)))
    return docs


def check_k8s(path, text, findings, state):
    for start, doc in split_yaml_docs(text):
        km = re.search(r"^\s*kind\s*:\s*([\w-]+)", doc, re.M)
        if not km:
            continue
        kind = km.group(1)
        if kind == "PodDisruptionBudget":
            state["has_pdb"] = True
            continue
        if kind not in WORKLOAD_KINDS:
            continue
        state["workloads"] += 1
        kind_line = start + doc[:km.start()].count("\n")
        if "livenessProbe:" not in doc:
            findings.append(Finding("CR001", path, kind_line, f"{kind} in {os.path.basename(path)}"))
        if "readinessProbe:" not in doc:
            findings.append(Finding("CR002", path, kind_line, f"{kind} in {os.path.basename(path)}"))
        if "resources:" not in doc:
            findings.append(Finding("CR003", path, kind_line, f"{kind} in {os.path.basename(path)}"))
        if kind != "DaemonSet":
            rm = re.search(r"^\s*replicas\s*:\s*1\s*$", doc, re.M)
            if rm:
                findings.append(Finding("CR004", path, start + doc[:rm.start()].count("\n")))
        for im in re.finditer(r"^\s*-?\s*image\s*:\s*[\"']?(\S+?)[\"']?\s*$", doc, re.M):
            image = im.group(1)
            if "{{" in image:
                continue  # helm-templated, can't judge
            tail = image.rsplit("/", 1)[-1]
            if ":" not in tail or tail.endswith(":latest"):
                findings.append(Finding("CR005", path, start + doc[:im.start()].count("\n"),
                                        f"image '{image}'"))
        if "envFrom:" in doc:
            state["env_wildcard"] = True
        for em in re.finditer(r"name\s*:\s*[\"']?([A-Z][A-Z0-9_]+)[\"']?", doc):
            state["defined_env"].add(em.group(1))


# --- azure paas ------------------------------------------------------------

def check_hostjson(path, text, findings):
    try:
        data = json.loads(text)
    except ValueError:
        return
    if "functionTimeout" not in data:
        findings.append(Finding("CR101", path, 1))


def check_logicapp(path, text, findings):
    for m in re.finditer(r'"retryPolicy"\s*:\s*\{[^{}]*"type"\s*:\s*"[Nn]one"', text):
        findings.append(Finding("CR102", path, text[:m.start()].count("\n") + 1))


def check_apim(path, text, findings):
    for m in re.finditer(r"<forward-request(?![^>]*\btimeout\s*=)[^>]*/?>", text):
        findings.append(Finding("CR103", path, text[:m.start()].count("\n") + 1))
    if "rate-limit" not in text:
        findings.append(Finding("CR104", path, line_of(text, r"<inbound")))


def check_bicep(path, text, findings, state):
    state["has_iac"] = True
    for m in re.finditer(r"resource\s+\w+\s+'Microsoft\.Web/sites@", text):
        if "healthCheckPath" not in text:
            findings.append(Finding("CR105", path, text[:m.start()].count("\n") + 1))
    for em in re.finditer(r"name\s*:\s*'([A-Z][A-Z0-9_]+)'", text):
        state["defined_env"].add(em.group(1))


# --- env definitions from config artifacts ---------------------------------

def collect_env_defs(kind, text, state):
    caps = re.compile(r"^\s*[\"'\-\s]*([A-Z][A-Z0-9_]+)[\"']?\s*[:=]", re.M)
    if kind in ("helmvalues", "compose", "envfile"):
        for m in caps.finditer(text):
            state["defined_env"].add(m.group(1))
    elif kind == "dockerfile":
        for m in re.finditer(r"^\s*ENV\s+([A-Za-z_][A-Za-z0-9_]*)", text, re.M):
            state["defined_env"].add(m.group(1))
    elif kind == "localsettings":
        try:
            values = json.loads(text).get("Values", {})
            state["defined_env"].update(values.keys())
        except ValueError:
            pass


# --- code side -------------------------------------------------------------

def check_code(path, text, state):
    for pat in ENV_READ_PATTERNS:
        for m in pat.finditer(text):
            key = m.group(1)
            line = text[:m.start()].count("\n") + 1
            state["env_reads"].setdefault(key, (path, line))
    for pat in POOL_PATTERNS:
        for m in pat.finditer(text):
            state["pools"].append((int(m.group(1)), path,
                                   text[:m.start()].count("\n") + 1))


def check_workflow(path, text, state):
    if DEPLOY_MARKERS.search(text):
        state["deploy_workflows"].append(path)


# --- drift + repo-level ----------------------------------------------------

def env_ignored(key, extra_ignore):
    if key in ENV_IGNORE_EXACT or key in extra_ignore:
        return True
    return any(key.startswith(p) for p in ENV_IGNORE_PREFIX)


def repo_level_checks(findings, state, args):
    if state["workloads"] and not state["has_pdb"]:
        findings.append(Finding("CR006", state["first_k8s_file"] or ".", 1))

    for key, (path, line) in sorted(state["env_reads"].items()):
        if env_ignored(key, state["extra_ignore"]):
            continue
        if key not in state["defined_env"]:
            f = Finding("CR201", path, line, f"'{key}'")
            if state["env_wildcard"]:
                f.detail += " (envFrom present — may be injected from a ConfigMap/Secret)"
            findings.append(f)

    if state["deploy_workflows"] and not (state["has_iac"] or state["workloads"]):
        findings.append(Finding("CR202", state["deploy_workflows"][0], 1))

    if args.db_max_connections and state["pools"]:
        replicas = state["max_replicas"] or 1
        pool, ppath, pline = max(state["pools"])
        total = replicas * pool
        if total > args.db_max_connections:
            findings.append(Finding(
                "CR203", ppath, pline,
                f"{replicas} replicas × pool {pool} = {total} > limit {args.db_max_connections}"))


# --- dependabot signal -----------------------------------------------------

def dependabot_open_alerts(repo, token):
    url = f"https://api.github.com/repos/{repo}/dependabot/alerts?state=open&per_page=100"
    req = urllib.request.Request(url, headers={
        "Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json"})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            alerts = json.load(resp)
            n = len(alerts)
            return f"{n}+" if n == 100 else str(n)
    except Exception:
        return None  # no permission or not enabled — skip silently


# --- output ----------------------------------------------------------------

def to_sarif(findings):
    rules = [{"id": rid, "name": RULES[rid][0].title().replace(" ", ""),
              "shortDescription": {"text": RULES[rid][0]},
              "fullDescription": {"text": RULES[rid][1]},
              "defaultConfiguration": {"level": RULES[rid][2]}}
             for rid in sorted(RULES)]
    results = [{
        "ruleId": f.rule,
        "level": RULES[f.rule][2],
        "message": {"text": f.message()},
        "locations": [{"physicalLocation": {
            "artifactLocation": {"uri": f.path.replace("\\", "/")},
            "region": {"startLine": f.line}}}],
    } for f in findings]
    return {
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
        "version": "2.1.0",
        "runs": [{"tool": {"driver": {
            "name": "Corvin R", "informationUri": "https://github.com/",
            "version": "0.1.0", "rules": rules}}, "results": results}],
    }


def grade(findings):
    w = sum(1 for f in findings if RULES[f.rule][2] == "warning")
    n = sum(1 for f in findings if RULES[f.rule][2] == "note")
    if w == 0:
        return ("A" if n <= 2 else "B"), w, n
    if w <= 2:
        return "B", w, n
    if w <= 5:
        return "C", w, n
    if w <= 10:
        return "D", w, n
    return "E", w, n


def summary_md(g, w, n, findings, state, detected, dependabot):
    lines = [
        "## Corvin R — resilience check",
        "",
        f"**Grade: {g}** · {w} warnings · {n} notes",
        "",
        "| Rule | Finding | Count |",
        "|---|---|---|",
    ]
    counts = {}
    for f in findings:
        counts[f.rule] = counts.get(f.rule, 0) + 1
    for rid in sorted(counts):
        lines.append(f"| {rid} | {RULES[rid][0]} | {counts[rid]} |")
    if not findings:
        lines.append("| — | No findings | 0 |")
    det = ", ".join(f"{v} {k}" for k, v in sorted(detected.items()) if v) or "no recognized artifacts"
    lines += ["", f"Detected: {det}."]
    if dependabot is not None:
        lines.append(f"Open Dependabot alerts: **{dependabot}** (feeds the resilience picture; "
                     "fix via Dependabot, not here).")
    if state["pools"] and not any(f.rule == "CR203" for f in findings):
        pool, _, _ = max(state["pools"])
        reps = state["max_replicas"] or "?"
        lines.append(f"Pool math: largest pool {pool} × {reps} replicas — provide "
                     "`db-max-connections` to enforce a limit.")
    lines.append("\n*Non-blocking: findings inform, the PR approver decides — dismiss "
                 "alerts with a reason to Accept Risk.*")
    return "\n".join(lines)


# --- main ------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description="Corvin R resilience scanner")
    ap.add_argument("--path", default=".")
    ap.add_argument("--out", default="corvin-r-out")
    ap.add_argument("--exclude", default="")
    ap.add_argument("--env-ignore", default="",
                    help="comma-separated env keys to ignore in drift check")
    ap.add_argument("--db-max-connections", type=int, default=None)
    ap.add_argument("--github-repo", default="", help="owner/repo for Dependabot signal")
    ap.add_argument("--fail-on-warnings", action="store_true")
    ap.add_argument("--corvin-api-url", default="")
    ap.add_argument("--corvin-api-token", default="")
    ap.add_argument("--app-id", default="")
    args = ap.parse_args()

    extra_excludes = {e.strip() for e in args.exclude.split(",") if e.strip()}
    findings = []
    state = {
        "workloads": 0, "has_pdb": False, "has_iac": False,
        "env_wildcard": False, "defined_env": set(), "env_reads": {},
        "pools": [], "deploy_workflows": [], "first_k8s_file": None,
        "max_replicas": 0,
        "extra_ignore": {e.strip() for e in args.env_ignore.split(",") if e.strip()},
    }
    detected = {}

    for dirpath, dirnames, filenames in os.walk(args.path):
        dirnames[:] = [d for d in dirnames
                       if d not in DEFAULT_EXCLUDE_DIRS and d not in extra_excludes]
        for fn in filenames:
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, args.path)
            try:
                with open(full, encoding="utf-8", errors="replace") as fh:
                    text = fh.read()
            except OSError:
                continue
            kind = classify(full.replace("\\", "/"), text)
            if kind is None:
                continue
            detected[kind] = detected.get(kind, 0) + 1

            if kind == "k8s":
                if state["first_k8s_file"] is None:
                    state["first_k8s_file"] = rel
                check_k8s(rel, text, findings, state)
                for rm in re.finditer(r"^\s*replicas\s*:\s*(\d+)", text, re.M):
                    state["max_replicas"] = max(state["max_replicas"], int(rm.group(1)))
            elif kind == "hostjson":
                check_hostjson(rel, text, findings)
            elif kind == "logicapp":
                check_logicapp(rel, text, findings)
            elif kind == "apim":
                check_apim(rel, text, findings)
            elif kind == "bicep":
                check_bicep(rel, text, findings, state)
            elif kind == "terraform":
                state["has_iac"] = True
            elif kind == "workflow":
                check_workflow(rel, text, state)
            elif kind == "code":
                check_code(rel, text, state)
            elif kind in ("helmvalues", "compose", "envfile", "dockerfile", "localsettings"):
                collect_env_defs(kind, text, state)

    repo_level_checks(findings, state, args)

    g, w, n = grade(findings)
    dependabot = None
    token = os.environ.get("GITHUB_TOKEN", "")
    if args.github_repo and token:
        dependabot = dependabot_open_alerts(args.github_repo, token)

    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "corvin-r.sarif"), "w", encoding="utf-8") as fh:
        json.dump(to_sarif(findings), fh, indent=2)
    payload = {
        "tool": "corvin-r",
        "appId": args.app_id or os.path.basename(os.path.abspath(args.path)),
        "grade": g, "warnings": w, "notes": n,
        "findings": {rid: sum(1 for f in findings if f.rule == rid)
                     for rid in sorted({f.rule for f in findings})},
        "detected": detected,
        "dependabotOpenAlerts": dependabot,
    }
    with open(os.path.join(args.out, "corvin-r-report.json"), "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2)

    md = summary_md(g, w, n, findings, state, detected, dependabot)
    step_summary = os.environ.get("GITHUB_STEP_SUMMARY")
    if step_summary:
        with open(step_summary, "a", encoding="utf-8") as fh:
            fh.write(md + "\n")
    print(md)
    gh_output = os.environ.get("GITHUB_OUTPUT")
    if gh_output:
        with open(gh_output, "a", encoding="utf-8") as fh:
            fh.write(f"grade={g}\nwarnings={w}\n")

    if args.corvin_api_url:
        req = urllib.request.Request(
            args.corvin_api_url, data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json",
                     **({"Authorization": f"Bearer {args.corvin_api_token}"}
                        if args.corvin_api_token else {})})
        try:
            urllib.request.urlopen(req, timeout=10)
            print("Report published to Corvin API.")
        except Exception as exc:
            print(f"WARN: Corvin API publish failed: {exc}", file=sys.stderr)

    if args.fail_on_warnings and w:
        print(f"{w} warnings and fail-on-warnings is set", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
