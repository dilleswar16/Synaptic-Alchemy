# Corvin R — resilience misses, flagged before merge

Corvin R scans a PR for **deterministic resilience problems**: platform config
that will fail badly (no probes, no timeouts, retry disabled), drift between
what the code needs and what the config defines, and repos that deploy with no
IaC at all. It grades the repo **A–E** and annotates findings in the PR via
GitHub code scanning. **Non-blocking by design** — findings inform, the PR
approver decides; dismissing an alert with a reason is the audit-trailed
Accept-Risk flow.

Nothing here guesses capacity from a code diff. Capacity comparisons belong to
production telemetry (Azure Advisor / KRR — on the roadmap below).

Covers: **Kubernetes/Helm, Azure Functions, Logic Apps, APIM policies, Bicep,
Terraform (presence), Dockerfiles, docker-compose, .env files** — plus the
code side in Java, C#, Python, JS/TS. Single stdlib-only Python file, zero
dependencies.

## What it checks

| Rule | Finding | Severity |
|---|---|---|
| `CR001` | Workload without a liveness probe | warning |
| `CR002` | Workload without a readiness probe | warning |
| `CR003` | No resource requests/limits | warning |
| `CR004` | Explicit `replicas: 1` | warning |
| `CR005` | Image with `:latest` or no tag | warning |
| `CR006` | Workloads but no PodDisruptionBudget in repo | note |
| `CR101` | Functions `host.json` without `functionTimeout` | note |
| `CR102` | Logic Apps action with `retryPolicy: none` | warning |
| `CR103` | APIM `forward-request` without `timeout` | warning |
| `CR104` | APIM policy without rate limiting | note |
| `CR105` | App Service (Bicep) without `healthCheckPath` | note |
| `CR201` | **Config drift** — env/config key read in code but defined in no manifest, values file, app settings, Dockerfile `ENV`, or `.env` | warning |
| `CR202` | **No IaC** — deploy workflow exists but repo has no manifests/IaC (click-opsed config) | warning |
| `CR203` | Pool math — replicas × pool size exceeds `db-max-connections` | warning |

Plus a **Dependabot signal**: the open alert count is read via the API and
shown in the report (never re-detected — Dependabot owns it).

**Grade:** A = no warnings (≤2 notes) · B ≤2 warnings · C ≤5 · D ≤10 · E >10.

## Install on a repository

Add `.github/workflows/corvin-r.yml`:

```yaml
name: Corvin R
on:
  pull_request:
    branches: [main, "release/**"]

permissions:
  contents: read
  security-events: write     # SARIF upload

jobs:
  resilience:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: YOUR_ORG/corvin-r@v1
        with:
          app-id: my-app
          db-max-connections: 100     # optional, enables pool-math enforcement
          env-ignore: FEATURE_FLAGS   # optional, silence known-injected keys
```

> **SARIF note:** free on public repos; private repos need GitHub Advanced
> Security. Without GHAS set `upload-sarif: false` — the grade, job summary,
> and JSON report still work.
> The Dependabot signal needs the default `github.token`; if the token lacks
> access the signal is skipped silently.

## Test it locally (no GitHub needed)

```bash
python corvin-r/src/corvin_r.py --path /path/to/your/repo --out /tmp/corvin-r

# Windows
python corvin-r\src\corvin_r.py --path C:\code\your-repo --out %TEMP%\corvin-r
```

Prints the graded summary; writes `corvin-r.sarif` and `corvin-r-report.json`.

Run the self-tests (two fixture repos with known findings):

```bash
python corvin-r/tests/run_tests.py
# PASS: main fixture (12 findings, grade D) and noiac fixture (2 findings, grade B)
```

The `tests/fixtures/main` folder doubles as a demo repo — point the scanner at
it to see every rule fire at least once.

## Test it on one of your repos (end to end)

1. Push this folder as its own repository (`git init && git add -A && git
   commit`, push, tag `v1`) — same steps as Corvin L's README.
2. Add the workflow above to a repo that has K8s manifests, Bicep, or Azure
   artifacts.
3. Open a PR. Easy ways to make it light up:
   - delete a `livenessProbe` block → CR001 on that Deployment
   - add `os.getenv("NOT_DEFINED_ANYWHERE")` to a Python file → CR201
   - set an image to `:latest` → CR005

## Design boundaries (read before filing issues)

- **Textual, not rendered.** Helm templates are checked as text — presence
  checks (probes, resources) work fine through `{{ }}`, but the scanner never
  renders charts. Templated image references are skipped rather than guessed.
- **Multi-container pods** are checked per-manifest, not per-container.
- **CR201 is conventional:** it recognizes UPPER_SNAKE keys and the standard
  read patterns (`os.getenv`, `process.env`, `System.getenv`, `@Value`,
  `GetEnvironmentVariable`). Keys injected at runtime (Key Vault references,
  ConfigMap `envFrom`) are downgraded or ignored — see `env-ignore`.
- **On-prem/VM apps:** platform config isn't in the repo, so R reports what it
  can see (code-side reads, deploy hygiene) and stays silent on what it can't.

## Enterprise deployment notes (MetLife pattern)

- Roll out via an organization ruleset / required workflow on release-branch
  PRs; pin by tag or SHA. Zero third-party dependencies to approve.
- **Roadmap:** swap CR001–CR006 for a forked, pinned kube-linter and add a
  curated PSRule-for-Azure Reliability profile for Bicep (same SARIF surface,
  richer rules); add Azure Advisor / forked-KRR rightsizing comparison; add
  the incident-history change-risk score once the ServiceNow export lands.
  Oracle/DB2 migration linting is acknowledged as unsolved.
