#!/usr/bin/env python3
"""Smoke tests for the Corvin R scanner against known fixtures."""
import json
import os
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "..", "src", "corvin_r.py")

EXPECTED_MAIN = {
    "findings": {"CR001": 1, "CR002": 1, "CR003": 1, "CR004": 1, "CR005": 1,
                 "CR006": 1, "CR101": 1, "CR102": 1, "CR103": 1, "CR104": 1,
                 "CR105": 1, "CR201": 1},
    "grade": "D", "warnings": 8, "notes": 4,
}
EXPECTED_NOIAC = {
    "findings": {"CR201": 1, "CR202": 1},
    "grade": "B", "warnings": 2, "notes": 0,
}


def run_case(fixture, expected):
    out = tempfile.mkdtemp(prefix="corvin-r-test-")
    proc = subprocess.run(
        [sys.executable, SRC, "--path", os.path.join(HERE, "fixtures", fixture),
         "--out", out],
        capture_output=True, text=True)
    if proc.returncode != 0:
        print(proc.stdout, proc.stderr)
        return [f"{fixture}: scanner exited non-zero"]
    with open(os.path.join(out, "corvin-r-report.json"), encoding="utf-8") as fh:
        payload = json.load(fh)
    failures = []
    for key in ("findings", "grade", "warnings", "notes"):
        if payload[key] != expected[key]:
            failures.append(f"{fixture}: {key} {payload[key]!r} != {expected[key]!r}")
    if failures:
        print(proc.stdout)
    return failures


def main():
    failures = run_case("main", EXPECTED_MAIN) + run_case("noiac", EXPECTED_NOIAC)
    if failures:
        for f in failures:
            print("FAIL:", f)
        return 1
    print("PASS: main fixture (12 findings, grade D) and noiac fixture "
          "(2 findings, grade B) — all as expected")
    return 0


if __name__ == "__main__":
    sys.exit(main())
