param location string = resourceGroup().location

resource site 'Microsoft.Web/sites@2023-12-01' = {
  name: 'corvin-demo-app'
  location: location
  properties: {
    httpsOnly: true
    siteConfig: {
      appSettings: [
        {
          name: 'QUEUE_NAME'
          value: 'orders'
        }
      ]
    }
  }
}
