async function loadOrders() {
  const res = await fetch("https://api.example.com/orders");
  return res.json();
}

module.exports = { loadOrders };
