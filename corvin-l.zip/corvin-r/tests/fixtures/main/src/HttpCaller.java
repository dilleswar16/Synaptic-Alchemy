package demo;

import org.springframework.web.client.RestTemplate;

public class HttpCaller {

    private final RestTemplate restTemplate = new RestTemplate();

    public String fetch() {
        return restTemplate.getForObject("https://api.example.com/orders", String.class);
    }
}
