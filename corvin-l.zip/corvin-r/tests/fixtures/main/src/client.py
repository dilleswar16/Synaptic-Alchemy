import requests


def fetch_orders():
    return requests.get("https://api.example.com/orders")


def fetch_with_timeout():
    return requests.get("https://api.example.com/orders", timeout=5)


def retry_fetch():
    for attempt in range(3):
        try:
            return requests.get("https://api.example.com/orders", timeout=5)
        except requests.RequestException:
            continue
    return None
