using Polly;

namespace Demo
{
    public static class Policies
    {
        public static readonly Policy Basic = Policy
            .Handle<System.Exception>()
            .Retry(3);
    }
}
