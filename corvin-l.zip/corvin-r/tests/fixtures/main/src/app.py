import os

foo = os.getenv("FOO")
bar = os.getenv("BAR")
queue = os.getenv("QUEUE_NAME")


def run():
    return foo, bar, queue
