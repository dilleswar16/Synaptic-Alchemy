using System;
using Microsoft.Extensions.Logging;

namespace Demo
{
    public class PaymentService
    {
        private readonly ILogger<PaymentService> _logger;

        public PaymentService(ILogger<PaymentService> logger)
        {
            _logger = logger;
        }

        public void Swallowed()
        {
            try
            {
                Process();
            }
            catch (Exception ex)
            {
            }
        }

        public void MessageOnly()
        {
            try
            {
                Process();
            }
            catch (Exception ex)
            {
                _logger.LogError("payment failed: " + ex.Message);
            }
        }

        public void ConsoleWrite()
        {
            Console.WriteLine("processing");
        }

        public void Good()
        {
            try
            {
                Process();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "payment failed");
                throw;
            }
        }

        private void Process()
        {
        }
    }
}
