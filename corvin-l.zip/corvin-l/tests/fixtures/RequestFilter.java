package demo;

import org.slf4j.MDC;

public class RequestFilter {

    public void apply(String correlationId) {
        MDC.put("correlationId", correlationId);
        try {
            proceed();
        } finally {
            MDC.clear();
        }
    }

    private void proceed() {
    }
}
