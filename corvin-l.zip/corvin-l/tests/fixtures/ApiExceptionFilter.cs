using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;

namespace Demo
{
    public class ApiExceptionFilter : IExceptionFilter
    {
        public void OnException(ExceptionContext context)
        {
            context.Result = new StatusCodeResult(500);
        }
    }

    public class LoggedExceptionFilter : IExceptionFilter
    {
        private readonly ILogger<LoggedExceptionFilter> _logger;

        public LoggedExceptionFilter(ILogger<LoggedExceptionFilter> logger)
        {
            _logger = logger;
        }

        public void OnException(ExceptionContext context)
        {
            _logger.LogError(context.Exception, "unhandled exception");
            context.Result = new StatusCodeResult(500);
        }
    }
}
