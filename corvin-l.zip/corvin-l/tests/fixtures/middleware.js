const logger = require("./logger");

function errorHandler(err, req, res, next) {
  res.status(500).json({ message: "internal error" });
}

function loggedErrorHandler(err, req, res, next) {
  logger.error("unhandled error", err);
  res.status(500).json({ message: "internal error" });
}

function forwardingHandler(err, req, res, next) {
  next(err);
}

module.exports = { errorHandler, loggedErrorHandler, forwardingHandler };
