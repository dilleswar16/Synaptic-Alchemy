const logger = require("./logger");
const client = require("./client");

async function fetchUser(id) {
  try {
    return await client.get(`/users/${id}`);
  } catch (err) {
  }
}

async function saveUser(user) {
  try {
    await client.post("/users", user);
  } catch (err) {
    logger.error("save failed: " + err.message);
  }
}

function legacyLoad() {
  return client.load().catch(err => {
    console.log(err);
  });
}

async function goodPath(user) {
  try {
    await client.put("/users", user);
  } catch (err) {
    logger.error("update failed", err);
    throw err;
  }
}

module.exports = { fetchUser, saveUser, legacyLoad, goodPath };
