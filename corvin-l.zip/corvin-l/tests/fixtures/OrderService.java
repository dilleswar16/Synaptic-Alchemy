package demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OrderService {
    private static final Logger log = LoggerFactory.getLogger(OrderService.class);

    public void swallowed() {
        try {
            process();
        } catch (Exception e) {
        }
    }

    public void messageOnly() {
        try {
            process();
        } catch (Exception e) {
            log.error("failed: " + e.getMessage());
        }
    }

    public void wrongLevel() {
        try {
            process();
        } catch (Exception e) {
            log.debug("something odd", e);
        }
    }

    public void consoleOut() {
        System.out.println("starting");
    }

    public void good() {
        try {
            process();
        } catch (Exception e) {
            log.error("process failed", e);
            throw new RuntimeException(e);
        }
    }

    private void process() {
    }
}
