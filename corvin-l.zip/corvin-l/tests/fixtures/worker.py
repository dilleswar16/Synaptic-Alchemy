import logging

logger = logging.getLogger(__name__)


def swallowed():
    try:
        run()
    except ValueError:
        pass


def message_only():
    try:
        run()
    except Exception as e:
        logger.error("run failed: %s", e)


def wrong_level():
    try:
        run()
    except KeyError as e:
        logger.debug("missing key %s", e)


def console_print():
    print("starting worker")


def good():
    try:
        run()
    except Exception:
        logger.exception("run failed")
        raise


def run():
    pass
