#!/usr/bin/env python3
"""Smoke tests for the Corvin L scanner against known fixtures."""
import json
import os
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "..", "src", "corvin_l.py")

EXPECTED_FINDINGS = {"CL001": 4, "CL002": 4, "CL003": 4, "CL004": 2,
                     "CL005": 1, "CL006": 2}
EXPECTED_CATCH_BLOCKS = 15
EXPECTED_ADVICE_HANDLERS = 8
EXPECTED_SCORE = 70.7


def main():
    out = tempfile.mkdtemp(prefix="corvin-l-test-")
    proc = subprocess.run(
        [sys.executable, SRC, "--path", os.path.join(HERE, "fixtures"),
         "--out", out, "--include-tests"],
        capture_output=True, text=True)
    if proc.returncode != 0:
        print(proc.stdout)
        print(proc.stderr)
        print("FAIL: scanner exited non-zero")
        return 1

    with open(os.path.join(out, "corvin-l-score.json"), encoding="utf-8") as fh:
        payload = json.load(fh)

    failures = []
    if payload["findings"] != EXPECTED_FINDINGS:
        failures.append(f"findings {payload['findings']} != {EXPECTED_FINDINGS}")
    if payload["stats"]["catch_blocks"] != EXPECTED_CATCH_BLOCKS:
        failures.append(f"catch_blocks {payload['stats']['catch_blocks']} != {EXPECTED_CATCH_BLOCKS}")
    if payload["stats"]["advice_handlers"] != EXPECTED_ADVICE_HANDLERS:
        failures.append(f"advice_handlers {payload['stats']['advice_handlers']} != {EXPECTED_ADVICE_HANDLERS}")
    if payload["stats"]["centralized_logging"] is not True:
        failures.append("centralized_logging flag not set by @RestControllerAdvice fixture")
    if payload["stats"]["structured_logging"] is not True:
        failures.append("structured_logging flag not set by logback.xml fixture")
    if payload["stats"]["correlation_ids"] is not True:
        failures.append("correlation_ids flag not set by RequestFilter MDC fixture")
    if abs(payload["score"] - EXPECTED_SCORE) > 0.05:
        failures.append(f"score {payload['score']} != {EXPECTED_SCORE}")

    sarif_path = os.path.join(out, "corvin-l.sarif")
    with open(sarif_path, encoding="utf-8") as fh:
        sarif = json.load(fh)
    n_results = len(sarif["runs"][0]["results"])
    n_expected = sum(EXPECTED_FINDINGS.values())
    if n_results != n_expected:
        failures.append(f"sarif results {n_results} != {n_expected}")

    if failures:
        print(proc.stdout)
        for f in failures:
            print("FAIL:", f)
        return 1
    print(f"PASS: {n_results} findings, score {payload['score']}, "
          f"{payload['stats']['catch_blocks']} handlers — all as expected")
    return 0


if __name__ == "__main__":
    sys.exit(main())
