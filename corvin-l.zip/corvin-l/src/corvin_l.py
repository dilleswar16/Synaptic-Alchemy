#!/usr/bin/env python3
"""Corvin L — logging-discipline scanner.

Scans Java, C#, Python, and JS/TS sources for logging indiscipline in
exception handling, computes a deterministic RCA-readiness score, and emits
SARIF + JSON + a markdown summary. Stdlib only; no third-party dependencies.

Rules:
  CL001  Swallowed exception   catch/except block that neither logs nor rethrows
  CL002  Stack trace lost      error/warn log in a catch block without the exception object
  CL003  Console logging       System.out / Console.Write / console.* / print() / printStackTrace
  CL004  Level misuse          catch block logs only at trace/debug/info
"""

import argparse
import json
import os
import re
import sys
import urllib.request

RULES = {
    "CL001": ("Swallowed exception",
              "This catch/except block neither logs the exception nor rethrows it. "
              "During an incident this failure will be invisible.", "warning"),
    "CL002": ("Stack trace lost",
              "The exception is logged without the exception object, so the stack trace "
              "is lost. Pass the exception itself to the logger.", "warning"),
    "CL003": ("Console logging",
              "Console output bypasses the logging framework: no level, no structure, "
              "often not shipped to the log platform.", "note"),
    "CL004": ("Error-path level misuse",
              "This catch block logs only below WARN. At production log levels the "
              "failure will be silent.", "warning"),
    "CL005": ("Silent exception handler",
              "This @ExceptionHandler/@AfterThrowing method handles exceptions "
              "centrally but never logs them — failures die silently at the edge.",
              "warning"),
    "CL006": ("Silent exception handler (C#/Express)",
              "This exception filter/middleware handles errors centrally but never "
              "logs them — failures die silently at the edge.", "warning"),
}

DEFAULT_EXCLUDE_DIRS = {
    "node_modules", "dist", "build", "target", "bin", "obj", ".git", ".venv",
    "venv", "__pycache__", "vendor", "coverage", ".next", "out",
}
DEFAULT_EXCLUDE_TESTS = re.compile(
    r"(^|[/\\])(tests?|__tests__|spec|testdata)([/\\]|$)|Tests?\.(java|cs)$|"
    r"\.(test|spec)\.(js|jsx|ts|tsx)$|(^|[/\\])test_[^/\\]+\.py$|_test\.py$",
    re.IGNORECASE)

LANG_BY_EXT = {
    ".java": "java", ".cs": "csharp", ".py": "python",
    ".js": "js", ".jsx": "js", ".ts": "js", ".tsx": "js",
}

# --- per-language patterns -------------------------------------------------

LOG_CALL = {
    "java": re.compile(r"\b(?:log(?:ger)?|LOG(?:GER)?)\s*\.\s*"
                       r"(trace|debug|info|warn|error|fatal)\s*\(", re.IGNORECASE),
    "csharp": re.compile(r"\b(?:_?log(?:ger)?)\s*\.\s*"
                         r"(?:Log)?(Trace|Debug|Information|Warning|Error|Critical|"
                         r"Info|Warn|Fatal)\s*\(", re.IGNORECASE),
    "js": re.compile(r"\b(?:log(?:ger)?|winston|pino)\s*\.\s*"
                     r"(trace|debug|info|warn|error|fatal)\s*\(", re.IGNORECASE),
    "python": re.compile(r"\b(?:log(?:ger|ging)?)\s*\.\s*"
                         r"(debug|info|warning|warn|error|critical|exception)\s*\(",
                         re.IGNORECASE),
}
ERROR_LEVELS = {"warn", "warning", "error", "fatal", "critical", "exception"}

CONSOLE = {
    "java": re.compile(r"System\s*\.\s*(out|err)\s*\.\s*print|\.printStackTrace\s*\("),
    "csharp": re.compile(r"\bConsole\s*\.\s*Write(Line)?\s*\("),
    "js": re.compile(r"\bconsole\s*\.\s*(log|error|warn|info|debug|trace)\s*\("),
    "python": re.compile(r"(?:^|[^.\w])print\s*\(|traceback\s*\.\s*print_exc\s*\("),
}

CATCH_RE = re.compile(r"\bcatch\b\s*(?:\(\s*(?:[\w.<>\[\]?|,\s]+?\s)?(\w+)\s*\))?")
PROMISE_CATCH = re.compile(r"\.catch\s*\(\s*(?:async\s+)?\(?\s*(\w+)?\s*\)?\s*=>\s*\{")
THROW_RE = re.compile(r"\bthrow\b")
ADVICE_ANNOT = re.compile(r"@(ExceptionHandler|AfterThrowing)\b")
CENTRAL_ADVICE = re.compile(r"@(?:Rest)?ControllerAdvice\b")
ASPECT = re.compile(r"@Aspect\b")
ASPECT_ADVICE = re.compile(r"@(?:AfterThrowing|Around)\b")
CS_HANDLER = re.compile(r"\b(?:void|Task(?:<[^>]*>)?|ValueTask(?:<[^>]*>)?)\s+"
                        r"OnException(?:Async)?\b|\bTryHandleAsync\b")
JS_ERROR_MW = re.compile(r"\(\s*(?:e|err\w*)\s*,\s*req\s*,\s*res\s*,\s*next\s*\)\s*(?:=>)?\s*\{")
JS_FORWARD = re.compile(r"\bnext\s*\(")

STRUCTURED_LOG = re.compile(
    r"LogstashEncoder|logstash-logback-encoder|JsonTemplateLayout|JsonLayout|"
    r"CompactJsonFormatter|Serilog\.Formatting\.Compact|"
    r"winston\.format\.json|\bpino\b|"
    r"structlog|python-json-logger|jsonlogger\.JsonFormatter")
CORRELATION = re.compile(
    r"\bMDC\s*\.\s*(?:put|get)|micrometer-tracing|spring-cloud-sleuth|"
    r"BeginScope\s*\(|Activity\.Current|TraceIdentifier|"
    r"AsyncLocalStorage|cls-hooked|correlation-id|[Xx]-[Cc]orrelation-[Ii][Dd]|"
    r"bind_contextvars")
CONFIG_EXTS = {".xml", ".json", ".yml", ".yaml", ".gradle", ".properties",
               ".csproj", ".config", ".toml"}
CONFIG_SKIP = {"package-lock.json", "yarn.lock", "pnpm-lock.yaml"}
COMMENT_LINE = re.compile(r"^\s*(//|\*|/\*|#)")


def strip_strings(line):
    """Blank out string literal contents so patterns don't match inside them."""
    return re.sub(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|`(?:\\.|[^`\\])*`',
                  lambda m: '"' + " " * (len(m.group(0)) - 2) + '"', line)


class Finding:
    def __init__(self, rule, path, line, detail=""):
        self.rule, self.path, self.line, self.detail = rule, path, line, detail


def find_block(lines, start_idx, open_col):
    """Return (end_idx, block_lines) for a brace block starting at lines[start_idx][open_col]."""
    depth = 0
    block = []
    for i in range(start_idx, len(lines)):
        seg = strip_strings(lines[i])
        start = open_col if i == start_idx else 0
        for j in range(start, len(seg)):
            c = seg[j]
            if c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    return i, block
        if depth > 0:
            if i != start_idx:
                block.append(lines[i])
        if i - start_idx > 400:  # runaway guard
            break
    return len(lines) - 1, block


def exception_referenced(var, log_lines, lang):
    """True if the exception variable is passed to a log call as an object."""
    if lang == "python":
        return any("exc_info" in ln or re.search(r"\.\s*exception\s*\(", ln)
                   for ln in log_lines)
    if not var:
        return True  # nothing to check against
    for ln in log_lines:
        for m in re.finditer(r"\b%s\b" % re.escape(var), ln):
            rest = ln[m.end():].lstrip()
            if not rest.startswith("."):          # standalone argument
                return True
            if lang == "js" and rest.startswith(".stack"):
                return True
    return False


def find_open_brace(text_lines, idx, col):
    """First '{' at/after (idx, col), searching up to 3 lines ahead (Allman style)."""
    for k in range(idx, min(idx + 4, len(text_lines))):
        seg = text_lines[k]
        pos = seg.find("{", col if k == idx else 0)
        if pos != -1:
            return k, pos
    return None, None


def analyze_braced(lines, lang, path, findings):
    """catch-block analysis for Java / C# / JS (try/catch and promise .catch)."""
    catch_blocks = 0
    text_lines = [strip_strings(ln) for ln in lines]

    handlers = []  # (catch_line_idx, brace_idx, brace_col, var)
    for idx, seg in enumerate(text_lines):
        if COMMENT_LINE.match(seg):
            continue
        for m in CATCH_RE.finditer(seg):
            before = seg[:m.start()].rstrip()
            if before.endswith("."):        # promise .catch handled below
                continue
            b_idx, b_col = find_open_brace(text_lines, idx, m.end())
            if b_idx is None:
                continue
            handlers.append((idx, b_idx, b_col, m.group(1)))
        if lang == "js":
            for m in PROMISE_CATCH.finditer(seg):
                handlers.append((idx, idx, seg.index("{", m.end() - 1), m.group(1)))

    for lineno_idx, b_idx, b_col, var in handlers:
        catch_blocks += 1
        _, block = find_block(lines, b_idx, b_col)
        first = lines[b_idx][b_col + 1:]
        body = ([first] if first.strip() else []) + block
        body_code = [b for b in body if b.strip() and not COMMENT_LINE.match(b)]
        body_text = "\n".join(strip_strings(b) for b in body_code)

        log_lines = [strip_strings(b) for b in body_code
                     if LOG_CALL[lang].search(strip_strings(b))]
        has_console = CONSOLE[lang].search(body_text)
        has_throw = THROW_RE.search(body_text)
        lineno = lineno_idx + 1

        if not log_lines and not has_throw and not has_console:
            findings.append(Finding("CL001", path, lineno))
            continue
        if log_lines:
            levels = {LOG_CALL[lang].search(b).group(1).lower() for b in log_lines}
            if levels.isdisjoint(ERROR_LEVELS):
                findings.append(Finding("CL004", path, lineno))
            elif var and not exception_referenced(var, log_lines, lang):
                findings.append(Finding("CL002", path, lineno))
    return catch_blocks


def find_body_brace(text_lines, idx, col):
    """First '{' at paren-depth 0 from (idx, col), up to 12 lines ahead.

    Paren tracking skips braces inside annotation arguments like
    @ExceptionHandler({A.class, B.class}).
    """
    depth = 0
    for k in range(idx, min(idx + 12, len(text_lines))):
        seg = text_lines[k]
        for j in range(col if k == idx else 0, len(seg)):
            c = seg[j]
            if c == "(":
                depth += 1
            elif c == ")":
                depth -= 1
            elif c == "{" and depth == 0:
                return k, j
    return None, None


def analyze_java_advice(lines, path, findings):
    """CL005: @ExceptionHandler / @AfterThrowing methods that never log.

    AOP advice only sees exceptions that propagate to it — but the advice
    method itself must log, or the failure dies silently at the edge.
    """
    handlers = 0
    text_lines = [strip_strings(ln) for ln in lines]
    for idx, seg in enumerate(text_lines):
        if COMMENT_LINE.match(seg):
            continue
        m = ADVICE_ANNOT.search(seg)
        if not m:
            continue
        b_idx, b_col = find_body_brace(text_lines, idx, m.end())
        if b_idx is None:
            continue
        handlers += 1
        _, block = find_block(lines, b_idx, b_col)
        first = lines[b_idx][b_col + 1:]
        body = ([first] if first.strip() else []) + block
        body_code = [b for b in body if b.strip() and not COMMENT_LINE.match(b)]
        body_text = "\n".join(strip_strings(b) for b in body_code)
        has_log = any(LOG_CALL["java"].search(strip_strings(b)) for b in body_code)
        if not has_log and not THROW_RE.search(body_text) \
                and not CONSOLE["java"].search(body_text):
            findings.append(Finding("CL005", path, idx + 1))
    return handlers


def analyze_handler_like(lines, lang, path, findings, decl_re, rule, ok_re=None):
    """Generic silent-central-handler check (CL006): a declaration matched by
    decl_re whose body has no log, no throw, no console — and, when ok_re is
    given (e.g. Express next(err)), no forwarding call either."""
    handlers = 0
    text_lines = [strip_strings(ln) for ln in lines]
    for idx, seg in enumerate(text_lines):
        if COMMENT_LINE.match(seg):
            continue
        m = decl_re.search(seg)
        if not m:
            continue
        if m.group(0).endswith("{"):
            b_idx, b_col = idx, m.end() - 1
        else:
            b_idx, b_col = find_body_brace(text_lines, idx, m.end())
        if b_idx is None:
            continue
        handlers += 1
        _, block = find_block(lines, b_idx, b_col)
        first = lines[b_idx][b_col + 1:]
        body = ([first] if first.strip() else []) + block
        body_code = [b for b in body if b.strip() and not COMMENT_LINE.match(b)]
        body_text = "\n".join(strip_strings(b) for b in body_code)
        has_log = any(LOG_CALL[lang].search(strip_strings(b)) for b in body_code)
        forwarded = ok_re.search(body_text) if ok_re else None
        if not has_log and not THROW_RE.search(body_text) \
                and not CONSOLE[lang].search(body_text) and not forwarded:
            findings.append(Finding(rule, path, idx + 1))
    return handlers


def analyze_python(lines, path, findings):
    catch_blocks = 0
    i = 0
    while i < len(lines):
        m = re.match(r"^(\s*)except\b(?:\s+[\w.()\s,]+?)?(?:\s+as\s+(\w+))?\s*:", lines[i])
        if not m:
            i += 1
            continue
        catch_blocks += 1
        indent, var = len(m.group(1)), m.group(2)
        body = []
        j = i + 1
        while j < len(lines):
            ln = lines[j]
            if ln.strip() and (len(ln) - len(ln.lstrip())) <= indent:
                break
            if ln.strip() and not COMMENT_LINE.match(ln):
                body.append(ln)
            j += 1
        body_text = "\n".join(strip_strings(b) for b in body)
        log_lines = [b for b in body if LOG_CALL["python"].search(strip_strings(b))]
        has_console = CONSOLE["python"].search(body_text)
        has_raise = re.search(r"\braise\b", body_text)
        lineno = i + 1

        if not log_lines and not has_raise and not has_console:
            findings.append(Finding("CL001", path, lineno))
        elif log_lines:
            levels = {LOG_CALL["python"].search(strip_strings(b)).group(1).lower()
                      for b in log_lines}
            if levels.isdisjoint(ERROR_LEVELS):
                findings.append(Finding("CL004", path, lineno))
            elif not exception_referenced(var, log_lines, "python"):
                findings.append(Finding("CL002", path, lineno))
        i = j
    return catch_blocks


def scan_console(lines, lang, path, findings):
    count = 0
    for idx, ln in enumerate(lines):
        if COMMENT_LINE.match(ln):
            continue
        if CONSOLE[lang].search(strip_strings(ln)):
            findings.append(Finding("CL003", path, idx + 1))
            count += 1
    return count


def count_log_statements(lines, lang):
    return sum(1 for ln in lines if LOG_CALL[lang].search(strip_strings(ln)))


# --- scoring ---------------------------------------------------------------

def compute_score(stats):
    """Deterministic 0-100 score. Components are rates, weights fixed."""
    catches = stats["catch_blocks"]
    handlers = catches + stats.get("advice_handlers", 0)
    silent = stats["cl001"] + stats.get("cl005", 0) + stats.get("cl006", 0)
    swallowed_ok = 1 - silent / handlers if handlers else 1.0
    if catches:
        level_ok = 1 - stats["cl004"] / catches
        error_logged = stats["error_logged_catches"]
        stack_ok = 1 - (stats["cl002"] / error_logged) if error_logged else 1.0
    else:
        level_ok = stack_ok = 1.0
    total_log = stats["log_statements"] + stats["cl003"]
    console_ok = 1 - (stats["cl003"] / total_log) if total_log else 1.0
    score = 100 * (0.35 * swallowed_ok + 0.25 * stack_ok +
                   0.15 * level_ok + 0.25 * console_ok)
    return round(score, 1)


# --- output ----------------------------------------------------------------

def to_sarif(findings):
    rules = [{"id": rid, "name": RULES[rid][0].replace(" ", ""),
              "shortDescription": {"text": RULES[rid][0]},
              "fullDescription": {"text": RULES[rid][1]},
              "defaultConfiguration": {"level": RULES[rid][2]}}
             for rid in sorted(RULES)]
    results = [{
        "ruleId": f.rule,
        "level": RULES[f.rule][2],
        "message": {"text": RULES[f.rule][1]},
        "locations": [{"physicalLocation": {
            "artifactLocation": {"uri": f.path.replace("\\", "/")},
            "region": {"startLine": f.line}}}],
    } for f in findings]
    return {
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
        "version": "2.1.0",
        "runs": [{"tool": {"driver": {
            "name": "Corvin L", "informationUri": "https://github.com/",
            "version": "0.1.0", "rules": rules}}, "results": results}],
    }


def summary_md(score, stats, findings, annotated):
    counts = {rid: sum(1 for f in findings if f.rule == rid) for rid in RULES}
    lines = [
        "## Corvin L — logging discipline",
        "",
        f"**Score: {score} / 100**"
        + ("" if stats["catch_blocks"] else " *(no exception handlers found — score reflects console usage only)*"),
        "",
        "| Rule | Finding | Count |",
        "|---|---|---|",
    ]
    for rid in sorted(RULES):
        lines.append(f"| {rid} | {RULES[rid][0]} | {counts[rid]} |")
    lines += [
        "",
        f"Scanned {stats['files']} files · {stats['catch_blocks']} exception handlers · "
        f"{stats.get('advice_handlers', 0)} advice/handler methods · "
        f"{stats['log_statements']} logger calls",
    ]
    if stats.get("centralized_logging"):
        lines.append("Centralized exception logging detected (Spring "
                     "`@ControllerAdvice` / logging aspect) — advice methods are "
                     "credited in the swallowed-exception rate.")
    if stats.get("structured_logging"):
        lines.append("Structured (JSON) logging configuration detected.")
    if stats.get("correlation_ids"):
        lines.append("Correlation-ID / MDC propagation detected.")
    if annotated is not None:
        lines.append(f"PR annotations limited to changed files: {annotated} findings shown.")
    lines.append("\n*Non-blocking: this check informs, the team decides.*")
    return "\n".join(lines)


# --- main ------------------------------------------------------------------

def iter_files(root, extra_excludes, include_tests):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in DEFAULT_EXCLUDE_DIRS
                       and d not in extra_excludes]
        for fn in filenames:
            ext = os.path.splitext(fn)[1].lower()
            if ext not in LANG_BY_EXT:
                continue
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, root)
            if not include_tests and DEFAULT_EXCLUDE_TESTS.search(rel):
                continue
            yield full, rel, LANG_BY_EXT[ext]


def main():
    ap = argparse.ArgumentParser(description="Corvin L logging-discipline scanner")
    ap.add_argument("--path", default=".")
    ap.add_argument("--out", default="corvin-l-out")
    ap.add_argument("--exclude", default="", help="comma-separated dir names to skip")
    ap.add_argument("--include-tests", action="store_true")
    ap.add_argument("--changed-file-list", default="",
                    help="file with changed paths; SARIF results filtered to these")
    ap.add_argument("--fail-below-score", type=float, default=None)
    ap.add_argument("--corvin-api-url", default="")
    ap.add_argument("--corvin-api-token", default="")
    ap.add_argument("--app-id", default="")
    args = ap.parse_args()

    extra_excludes = {e.strip() for e in args.exclude.split(",") if e.strip()}
    findings, stats = [], {
        "files": 0, "catch_blocks": 0, "advice_handlers": 0,
        "log_statements": 0,
        "cl001": 0, "cl002": 0, "cl003": 0, "cl004": 0, "cl005": 0, "cl006": 0,
        "error_logged_catches": 0, "centralized_logging": False,
        "structured_logging": False, "correlation_ids": False,
    }

    for full, rel, lang in iter_files(args.path, extra_excludes, args.include_tests):
        try:
            with open(full, encoding="utf-8", errors="replace") as fh:
                lines = fh.read().splitlines()
        except OSError:
            continue
        stats["files"] += 1
        before = len(findings)
        if lang == "python":
            stats["catch_blocks"] += analyze_python(lines, rel, findings)
        else:
            stats["catch_blocks"] += analyze_braced(lines, lang, rel, findings)
        text = "\n".join(lines)
        if lang == "java":
            stats["advice_handlers"] += analyze_java_advice(lines, rel, findings)
            if CENTRAL_ADVICE.search(text) or (
                    ASPECT.search(text) and ASPECT_ADVICE.search(text)
                    and LOG_CALL["java"].search(text)):
                stats["centralized_logging"] = True
        elif lang == "csharp":
            stats["advice_handlers"] += analyze_handler_like(
                lines, "csharp", rel, findings, CS_HANDLER, "CL006")
        elif lang == "js":
            stats["advice_handlers"] += analyze_handler_like(
                lines, "js", rel, findings, JS_ERROR_MW, "CL006", JS_FORWARD)
        if not stats["structured_logging"] and STRUCTURED_LOG.search(text):
            stats["structured_logging"] = True
        if not stats["correlation_ids"] and CORRELATION.search(text):
            stats["correlation_ids"] = True
        scan_console(lines, lang, rel, findings)
        stats["log_statements"] += count_log_statements(lines, lang)
        for f in findings[before:]:
            key = f.rule.lower()
            stats[key] = stats.get(key, 0) + 1

    # maturity flags can also live in config files the code walk never visits
    # (logback.xml, appsettings.json, package.json, pyproject.toml, ...)
    if not (stats["structured_logging"] and stats["correlation_ids"]):
        for dirpath, dirnames, filenames in os.walk(args.path):
            dirnames[:] = [d for d in dirnames if d not in DEFAULT_EXCLUDE_DIRS
                           and d not in extra_excludes]
            for fn in filenames:
                if fn.lower() in CONFIG_SKIP:
                    continue
                if os.path.splitext(fn)[1].lower() not in CONFIG_EXTS \
                        and fn.lower() not in ("requirements.txt", "pipfile"):
                    continue
                full = os.path.join(dirpath, fn)
                try:
                    if os.path.getsize(full) > 262144:
                        continue
                    with open(full, encoding="utf-8", errors="replace") as fh:
                        cfg_text = fh.read()
                except OSError:
                    continue
                if STRUCTURED_LOG.search(cfg_text):
                    stats["structured_logging"] = True
                if CORRELATION.search(cfg_text):
                    stats["correlation_ids"] = True

    # catches that logged at error level (denominator for CL002 rate):
    # approximated as catches minus swallowed minus level-misused
    stats["error_logged_catches"] = max(
        0, stats["catch_blocks"] - stats["cl001"] - stats["cl004"])

    score = compute_score(stats)

    changed = None
    if args.changed_file_list and os.path.exists(args.changed_file_list):
        with open(args.changed_file_list, encoding="utf-8") as fh:
            changed = {ln.strip().replace("\\", "/") for ln in fh if ln.strip()}
    sarif_findings = findings
    annotated = None
    if changed is not None:
        sarif_findings = [f for f in findings
                          if f.path.replace("\\", "/") in changed]
        annotated = len(sarif_findings)

    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "corvin-l.sarif"), "w", encoding="utf-8") as fh:
        json.dump(to_sarif(sarif_findings), fh, indent=2)
    payload = {"tool": "corvin-l", "appId": args.app_id or os.path.basename(
        os.path.abspath(args.path)), "score": score, "stats": stats,
        "findings": {rid: sum(1 for f in findings if f.rule == rid) for rid in RULES}}
    with open(os.path.join(args.out, "corvin-l-score.json"), "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2)

    md = summary_md(score, stats, findings, annotated)
    step_summary = os.environ.get("GITHUB_STEP_SUMMARY")
    if step_summary:
        with open(step_summary, "a", encoding="utf-8") as fh:
            fh.write(md + "\n")
    print(md)
    gh_output = os.environ.get("GITHUB_OUTPUT")
    if gh_output:
        with open(gh_output, "a", encoding="utf-8") as fh:
            fh.write(f"score={score}\n")

    if args.corvin_api_url:
        req = urllib.request.Request(
            args.corvin_api_url, data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json",
                     **({"Authorization": f"Bearer {args.corvin_api_token}"}
                        if args.corvin_api_token else {})})
        try:
            urllib.request.urlopen(req, timeout=10)
            print("Score published to Corvin API.")
        except Exception as exc:  # publishing must never fail the check
            print(f"WARN: Corvin API publish failed: {exc}", file=sys.stderr)

    if args.fail_below_score is not None and score < args.fail_below_score:
        print(f"Score {score} below threshold {args.fail_below_score}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
