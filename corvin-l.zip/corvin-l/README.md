# Corvin L — logging discipline, scored on every PR

Corvin L scans your code at PR time and answers one question: **if this app
breaks in production, will the logs be good enough to find out why?**
It produces a deterministic 0–100 score plus per-line findings, annotated in
the PR via GitHub code scanning. It is **non-blocking by design** — the check
informs, the team decides.

Supported languages: **Java, C#, Python, JavaScript/TypeScript** (Node and
React). No dependencies — the scanner is a single stdlib-only Python file.

## What it checks

| Rule | Finding | Severity | Why it matters for RCA |
|---|---|---|---|
| `CL001` | **Swallowed exception** — catch/except that neither logs nor rethrows | warning | The failure is invisible during an incident |
| `CL002` | **Stack trace lost** — error logged without the exception object (`log.error(e.getMessage())`) | warning | You know *that* it failed, never *where* |
| `CL003` | **Console logging** — `System.out`, `Console.WriteLine`, `console.*`, `print()`, `printStackTrace()` | note | No level, no structure, often never shipped to the log platform |
| `CL004` | **Error-path level misuse** — catch block logs only at trace/debug/info | warning | Silent at production log levels |

Deliberately **not** checked: entry/exit logging per method. Counting those
rewards log spam; distributed tracing solves that problem without discipline.

## The score

```
score = 100 × ( 0.35 × swallowed-free rate      # 1 − CL001/handlers
              + 0.25 × stack-trace rate          # 1 − CL002/error-logging handlers
              + 0.15 × level-correct rate        # 1 − CL004/handlers
              + 0.25 × framework-logging rate )  # 1 − console/(logger+console calls)
```

Fully deterministic — same code in, same score out, no LLM in the number.
If a repo has no exception handlers at all, the handler components are neutral
and the summary says so explicitly.

## Install on a repository

Add `.github/workflows/corvin-l.yml`:

```yaml
name: Corvin L
on:
  pull_request:
    branches: [main, "release/**"]

permissions:
  contents: read
  security-events: write     # for SARIF upload

jobs:
  logging-discipline:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0     # needed for PR diff detection
      - uses: YOUR_ORG/corvin-l@v1
        with:
          app-id: my-app
```

Until you push this folder as its own repo (see below), you can also reference
it from a monorepo path: `uses: YOUR_ORG/GitActionPlugins/corvin-l@main`.

### Inputs

| Input | Default | Notes |
|---|---|---|
| `path` | `.` | Root directory to scan |
| `exclude` | — | Extra comma-separated directory names to skip (`generated,migrations`) |
| `include-tests` | `false` | Test files are skipped by default |
| `diff-only` | `true` | On PRs, only changed files get annotations; the score still covers the whole repo |
| `upload-sarif` | `true` | Set `false` on private repos without Advanced Security |
| `fail-below-score` | — | Empty = never block (recommended). Set a number to gate |
| `app-id` / `corvin-api-url` / `corvin-api-token` | — | Publish the score JSON to Corvin once the platform is live |

### Where results appear

1. **PR annotations + Security tab** — via SARIF upload (category `corvin-l`).
   Dismissing an alert with a reason is the audit-trailed Accept-Risk flow.
2. **Job summary** — score, rule counts, handler stats on the workflow run page.
3. **`score` output** — for downstream steps (badges, gates, dashboards).
4. **Corvin API** — optional POST of the full JSON payload.

> **SARIF note:** upload works on public repos for free; private repos need
> GitHub Advanced Security. Without GHAS set `upload-sarif: false` — you keep
> the score and the job summary.

## Test it locally (no GitHub needed)

```bash
# scan any project folder
python corvin-l/src/corvin_l.py --path /path/to/your/repo --out /tmp/corvin-l

# on Windows
python corvin-l\src\corvin_l.py --path C:\code\your-repo --out %TEMP%\corvin-l
```

You get the summary on stdout plus `corvin-l.sarif` and `corvin-l-score.json`
in the output folder.

Run the self-tests (fixtures with known findings in all four languages):

```bash
python corvin-l/tests/run_tests.py
# PASS: 14 findings, score 70.4, 15 handlers — all as expected
```

## Test it on one of your repos (end to end)

1. Push this folder to its own repository, e.g. `corvin-l`:
   ```bash
   cd corvin-l && git init && git add -A && git commit -m "Corvin L v0.1"
   git remote add origin https://github.com/YOU/corvin-l.git
   git push -u origin main && git tag v1 && git push --tags
   ```
2. In any repo you want scanned, add the workflow above with
   `uses: YOU/corvin-l@v1`.
3. Open a PR that touches a source file — check the **Checks** tab for the
   summary and **Files changed** for inline annotations.
4. To see it light up, add a `try { } catch (e) { }` swallowed exception to
   the PR and watch CL001 appear on that exact line.

## Enterprise deployment notes (MetLife pattern)

- **Org-wide rollout:** enforce via an organization ruleset / required
  workflow targeting PRs to release branches, so individual repos don't need
  to adopt anything.
- **Pin, don't float:** reference the action by tag or SHA. The action has
  zero third-party dependencies by design — nothing to approve beyond the
  action itself.
- **Roadmap here:** the regex/heuristic engine is v0.1. The scoped v1 target
  is CodeQL custom query packs per language (dataflow precision, same PR
  surface); the score formula, SARIF shape, and API payload stay identical, so
  the swap is invisible to consumers. A PII penalty (consuming CodeQL CWE-532
  findings) and repo-level observability maturity flags are next.

## Known limitations (honest list)

- Heuristic parsing: brace-matching ignores braces inside comments spanning
  lines; multi-line string literals can confuse it. Precision is tuned for
  common enterprise code styles.
- `print()`/`console.log` in CLI tools is flagged too — use `exclude` for
  legitimate console apps, or ignore the note-level findings.
- Python `except` blocks nested inside another `except` body are not analyzed.
- Log calls made through custom wrapper utilities (`AppLogger.write(...)`)
  are not recognized as framework logging yet — add your wrapper to the regex
  in `src/corvin_l.py` (`LOG_CALL`) if this is your house style.
