# Corvin GitHub Actions — L (Logs) and R (Resilience)

Two non-blocking PR checks that put engineering indiscipline in front of the
people merging it:

| | What it does | Output |
|---|---|---|
| **[Corvin L](corvin-l/)** | Scores logging discipline (swallowed exceptions, lost stack traces, console logging, level misuse, silent Spring AOP handlers) in Java, C#, Python, JS/TS | Score 0–100 + SARIF + summary |
| **[Corvin R](corvin-r/)** | Flags resilience misses in K8s/Helm, Azure Functions/Logic Apps/APIM/Bicep config, code-vs-config drift, missing IaC | Grade A–E + SARIF + summary |

Both are **composite GitHub Actions** with a single stdlib-only Python scanner
each — no third-party dependencies, nothing to security-review beyond the
action itself. Findings upload as SARIF to GitHub code scanning, so they
appear in the same PR annotation UI as CodeQL, and alert dismissal-with-reason
serves as the audit-trailed Accept-Risk workflow. Both can POST their result
JSON to the Corvin platform API once it is live; until then they are fully
standalone.

## Quick start

```bash
# run the self-tests
python corvin-l/tests/run_tests.py
python corvin-r/tests/run_tests.py

# scan any local repo, no GitHub needed
python corvin-l/src/corvin_l.py --path C:\code\some-repo --out %TEMP%\l
python corvin-r/src/corvin_r.py --path C:\code\some-repo --out %TEMP%\r
```

To use them in workflows, push each folder as its own repository and tag it
(`v1`), then reference `YOUR_ORG/corvin-l@v1` / `YOUR_ORG/corvin-r@v1` from
any repo's workflow. Each subfolder's README has the full workflow YAML,
input reference, and end-to-end test walkthrough.

## Rule code reference

Complete map of rule codes — implemented today vs reserved for the roadmap.
IDs are stable: a planned rule ships under the ID listed here.

### Corvin L (`CL…` findings, `ML…` maturity flags)

| Code | Rule | Severity | Status |
|---|---|---|---|
| CL001 | Swallowed exception — catch/except that neither logs nor rethrows | warning | ✅ Implemented |
| CL002 | Stack trace lost — error logged without the exception object | warning | ✅ Implemented |
| CL003 | Console logging — `System.out` / `Console.Write` / `console.*` / `print()` / `printStackTrace()` | note | ✅ Implemented |
| CL004 | Error-path level misuse — catch logs only at trace/debug/info | warning | ✅ Implemented |
| CL005 | Silent exception handler — Spring `@ExceptionHandler`/`@AfterThrowing` with no log | warning | ✅ Implemented |
| CL006 | Silent handler parity — C# exception middleware/`IExceptionFilter`, Express error middleware with no log | warning | ✅ Implemented |
| CL007 | Low-information error message — bare `"error"`/`"failed"` literals with no context or arguments | note | 🔜 Planned |
| CL008 | Overly broad catch — `catch (Throwable)` / bare `except:` outside boundary code | note | 🔜 Planned |
| CL009 | PII penalty — consume CodeQL CWE-532 (sensitive data in logs) findings via API into the score | — | 🔜 Planned (consume, not build) |
| ML: `centralized_logging` | Spring `@ControllerAdvice` / logging aspect detected; advice methods credited in score | flag | ✅ Implemented |
| ML: `structured_logging` | JSON log encoder configured (logback/Serilog/winston/structlog) | flag | ✅ Implemented |
| ML: `correlation_ids` | MDC / correlation-ID propagation present | flag | ✅ Implemented |

### Corvin R (`CR…` findings)

| Code | Rule | Severity | Status |
|---|---|---|---|
| CR001 | Workload without liveness probe | warning | ✅ Implemented |
| CR002 | Workload without readiness probe | warning | ✅ Implemented |
| CR003 | No resource requests/limits | warning | ✅ Implemented |
| CR004 | Explicit `replicas: 1` | warning | ✅ Implemented |
| CR005 | Image `:latest` or untagged | warning | ✅ Implemented |
| CR006 | Workloads but no PodDisruptionBudget | note | ✅ Implemented |
| CR007 | Scalable workload but no HorizontalPodAutoscaler | note | 🔜 Planned |
| CR008 | No graceful-shutdown config (preStop / termination grace) | note | 🔜 Planned |
| CR009 | `replicas > 1` but no anti-affinity / topology spread (all replicas can land on one node) | warning | ✅ Implemented |
| CR101 | Functions `host.json` without `functionTimeout` | note | ✅ Implemented |
| CR102 | Logic Apps action with `retryPolicy: none` | warning | ✅ Implemented |
| CR103 | APIM `forward-request` without timeout | warning | ✅ Implemented |
| CR104 | APIM policy without rate limiting | note | ✅ Implemented |
| CR105 | App Service (Bicep) without `healthCheckPath` | note | ✅ Implemented |
| CR106 | APIM policy without retry | note | 🔜 Planned |
| CR107 | Logic Apps trigger without concurrency limit | note | 🔜 Planned |
| CR108 | Richer Bicep reliability (alwaysOn, zone redundancy, autoscale) via curated PSRule profile | — | 🔜 Planned (wrap PSRule) |
| CR201 | Config key read in code but defined nowhere (drift) | warning | ✅ Implemented |
| CR202 | Deploy workflow but no IaC in repo | warning | ✅ Implemented |
| CR203 | Pool math — replicas × pool size exceeds DB limit | warning | ✅ Implemented |
| CR204 | Outbound HTTP/DB call without a timeout (code-level, all 4 languages) | warning | ✅ Implemented |
| CR205 | Retry loop without backoff (retry-storm risk) | warning | ✅ Implemented |
| CR206 | API breaking change on spec files (forked oasdiff) | warning | 🔜 Planned (fork) |
| CR301 | Rightsizing vs evidence — Azure Advisor / forked-KRR recommendations vs PR config | warning | 🔜 Planned |
| CR401 | Incident-history change risk — PR touches code implicated in past ServiceNow incidents | — | 🔜 Phase 2 (needs ServiceNow export) |

Signals that are consumed, never rebuilt: open Dependabot alert count
(✅ implemented, shown in R's report), CodeQL CWE-532 for CL009.

## Principles (carried from the design assessment)

- **Non-blocking:** the check informs, the team decides. Scores trend; gates
  are opt-in (`fail-below-score`, `fail-on-warnings`).
- **Deterministic numbers:** no LLM anywhere in a score or grade — identical
  code always produces the identical result, so it can't be argued with.
- **Never rebuild what exists:** dependency risk is Dependabot's (consumed via
  API), PII-in-logs is CodeQL CWE-532's (roadmap), Accept-Risk is GitHub alert
  dismissal.
- **No capacity guessing from diffs:** capacity comparisons come from
  production evidence (Azure Advisor / KRR) — on the roadmap, not faked.
- **Minimal OSS surface:** v0.1 is dependency-free; the roadmap adds only
  vendor-backed tools (PSRule/Microsoft, Checkov/Palo Alto) or forked-and-
  pinned niche ones (kube-linter, oasdiff, KRR).
