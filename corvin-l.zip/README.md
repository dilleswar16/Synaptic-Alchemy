# Corvin GitHub Actions — L (Logs) and R (Resilience)

Two non-blocking PR checks that put engineering indiscipline in front of the
people merging it:

| | What it does | Output |
|---|---|---|
| **[Corvin L](corvin-l/)** | Scores logging discipline (swallowed exceptions, lost stack traces, console logging, level misuse) in Java, C#, Python, JS/TS | Score 0–100 + SARIF + summary |
| **[Corvin R](corvin-r/)** | Flags resilience misses in K8s/Helm, Azure Functions/Logic Apps/APIM/Bicep config, code-vs-config drift, missing IaC | Grade A–E + SARIF + summary |

Both are **composite GitHub Actions** with a single stdlib-only Python scanner
each — no third-party dependencies, nothing to security-review beyond the
action itself. Findings upload as SARIF to GitHub code scanning, so they
appear in the same PR annotation UI as CodeQL, and alert dismissal-with-reason
serves as the audit-trailed Accept-Risk workflow. Both can POST their result
JSON to the Corvin platform API once it is live; until then they are fully
standalone.

## Quick start

```bash
# run the self-tests
python corvin-l/tests/run_tests.py
python corvin-r/tests/run_tests.py

# scan any local repo, no GitHub needed
python corvin-l/src/corvin_l.py --path C:\code\some-repo --out %TEMP%\l
python corvin-r/src/corvin_r.py --path C:\code\some-repo --out %TEMP%\r
```

To use them in workflows, push each folder as its own repository and tag it
(`v1`), then reference `YOUR_ORG/corvin-l@v1` / `YOUR_ORG/corvin-r@v1` from
any repo's workflow. Each subfolder's README has the full workflow YAML,
input reference, and end-to-end test walkthrough.

## Principles (carried from the design assessment)

- **Non-blocking:** the check informs, the team decides. Scores trend; gates
  are opt-in (`fail-below-score`, `fail-on-warnings`).
- **Deterministic numbers:** no LLM anywhere in a score or grade — identical
  code always produces the identical result, so it can't be argued with.
- **Never rebuild what exists:** dependency risk is Dependabot's (consumed via
  API), PII-in-logs is CodeQL CWE-532's (roadmap), Accept-Risk is GitHub alert
  dismissal.
- **No capacity guessing from diffs:** capacity comparisons come from
  production evidence (Azure Advisor / KRR) — on the roadmap, not faked.
- **Minimal OSS surface:** v0.1 is dependency-free; the roadmap adds only
  vendor-backed tools (PSRule/Microsoft, Checkov/Palo Alto) or forked-and-
  pinned niche ones (kube-linter, oasdiff, KRR).
